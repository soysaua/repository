window.location.replace(
  "https://sites.google.com/education.nsw.gov.au/Unblox-the-unblocked"
);
